# AUTO-FULL-PLUS
Página completa + backend com defaults: `cnpj_remetente` e `nota_fiscal`.
Se souber o caminho exato, defina `BRUDAM_ENDPOINT_PATH` (ex.: `/tracking/ocorrencias/minuta`).
